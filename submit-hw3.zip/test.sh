ant clean
ant all
sudo cp master.war /usr/share/jetty/webapps
#sudo cp worker.war /usr/share/jetty/webapps
