ant clean
ant all
sudo cp worker.war /media/sf_shared/jetty-8081/webapps
