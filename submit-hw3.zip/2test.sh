ant clean
ant all
sudo cp worker.war /media/sf_shared/jetty-8082/webapps

